from flask import Flask, request, jsonify
from flask_cors import CORS
import json
import os

app = Flask(__name__)
# Enable CORS for frontend running on a different port/origin
CORS(app) 

DATA_FILE = 'library_data.json'

# --- Utility Functions for File I/O ---

def load_data():
    """Loads data from the JSON file."""
    if not os.path.exists(DATA_FILE):
        return {"books": []}
    try:
        with open(DATA_FILE, 'r') as f:
            # Handle empty file case
            content = f.read()
            if not content:
                return {"books": []}
            return json.loads(content)
    except Exception as e:
        print(f"Error loading data: {e}")
        return {"books": []}

def save_data(data):
    """Saves data to the JSON file."""
    try:
        with open(DATA_FILE, 'w') as f:
            json.dump(data, f, indent=2)
    except Exception as e:
        print(f"Error saving data: {e}")

# --- API Endpoints ---

@app.route('/api/books', methods=['GET'])
def get_books():
    """Endpoint to list all books."""
    data = load_data()
    return jsonify({"books": data.get("books", [])})

@app.route('/api/books/add', methods=['POST'])
def add_book():
    """Endpoint to add a new book."""
    try:
        new_book_data = request.json
        data = load_data()
        books = data.get("books", [])
        
        # Simple ID generation
        next_id = max([book['id'] for book in books], default=0) + 1
        
        # Prepare new book object
        new_book = {
            "id": next_id,
            "title": new_book_data['title'],
            "author": new_book_data['author'],
            "isbn": new_book_data['isbn'],
            "publication_year": int(new_book_data['publication_year']),
            "is_borrowed": False,
            "borrowed_by": None
        }
        
        books.append(new_book)
        data["books"] = books
        save_data(data)
        
        return jsonify({"message": "Book added successfully", "book": new_book}), 201
        
    except Exception as e:
        return jsonify({"error": f"Invalid input or server error: {e}"}), 400

@app.route('/api/books/search', methods=['GET'])
def search_books():
    """Endpoint to search books by title or author (case-insensitive)."""
    query = request.args.get('query', '').lower()
    data = load_data()
    books = data.get("books", [])
    
    if not query:
        return jsonify({"books": books})
        
    results = [
        book for book in books
        if query in book['title'].lower() or query in book['author'].lower()
    ]
    
    return jsonify({"books": results})

@app.route('/api/transaction/borrow', methods=['POST'])
def borrow_book():
    """Endpoint to handle borrowing a book."""
    try:
        req_data = request.json
        book_id = int(req_data['id'])
        borrower_name = req_data['borrower_name']
        
        data = load_data()
        books = data.get("books", [])
        
        book = next((b for b in books if b['id'] == book_id), None)
        
        if not book:
            return jsonify({"error": "Book not found."}), 404
            
        if book['is_borrowed']:
            return jsonify({"error": f"Book is already borrowed by {book['borrowed_by']}."}), 409
            
        book['is_borrowed'] = True
        book['borrowed_by'] = borrower_name
        
        save_data(data)
        return jsonify({"message": f"Book '{book['title']}' borrowed successfully by {borrower_name}."})
        
    except Exception as e:
        return jsonify({"error": f"Invalid request or server error: {e}"}), 400

@app.route('/api/transaction/return', methods=['POST'])
def return_book():
    """Endpoint to handle returning a book."""
    try:
        req_data = request.json
        book_id = int(req_data['id'])
        
        data = load_data()
        books = data.get("books", [])
        
        book = next((b for b in books if b['id'] == book_id), None)
        
        if not book:
            return jsonify({"error": "Book not found."}), 404
            
        if not book['is_borrowed']:
            return jsonify({"error": f"Book '{book['title']}' is not currently borrowed."}), 409
            
        borrower = book['borrowed_by']
        book['is_borrowed'] = False
        book['borrowed_by'] = None
        
        save_data(data)
        return jsonify({"message": f"Book '{book['title']}' returned successfully by {borrower}."})
        
    except Exception as e:
        return jsonify({"error": f"Invalid request or server error: {e}"}), 400

if __name__ == '__main__':
    print("Starting Flask server...")
    print("Access the UI at: http://localhost:5000/")
    # Running on port 5000, accessible from the frontend HTML file
    app.run(debug=True, port=5000)